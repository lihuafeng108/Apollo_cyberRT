To launch this test open two different consoles:

In the first one launch: HelloWorldExample publisher (or HelloWorldExample.exe publisher on windows).
In the second one: HelloWorldExample subscriber.

Note: This example needs the xml file stored in the sources directory. You need to copy this folder where you will execute the example executable. The CMakeList.txt file also copies this file to the folder used to build the example.
