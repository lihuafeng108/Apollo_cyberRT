To launch this example open two different consoles:

In the first one launch: ./XMLProfile publisher (or XMLProfile.exe publisher on Windows).
In the second one: ./XMLProfile subscriber.

Note: This example needs the xml file stored in the sources directory. You need to copy this folder where you will execute the example executable. The CMakeList.txt file also copies this file to the folder used to build the example.
